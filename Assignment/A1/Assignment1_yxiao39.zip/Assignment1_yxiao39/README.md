# EN.601.454/654 Augmented Reality
## Assignment 1
Name: Yuliang Xiao
JHED: yxiao39
Date: 09/13/2022
Unity Version: 2021.3.9f1 MacOS M1 (LTS)

### Contents
1. Roll-a-Ball Tutorial Unity Package
2. Creative Unity Package

### Required Packages:
1. ProBuilder
2. Input System

### Clarifications
1. Create a new project with 3D (URP) template.
2. Install required packages listed above.
3. Click the unitypackage to import the scenes.